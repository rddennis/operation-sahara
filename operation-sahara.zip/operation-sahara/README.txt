Welcome to Operation Sahara.

Inside this ZIP, you will find files and directories used in your Day 1 Linux navigation mission. 
Extract the files, follow the instructions in mission/briefing.txt, and complete all tasks.

Good luck.